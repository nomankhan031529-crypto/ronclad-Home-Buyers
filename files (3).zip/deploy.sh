#!/usr/bin/env bash
# Deploy Ironclad Home Buyers to Cloudflare Pages via the Cloudflare API
# (using Wrangler, Cloudflare's official CLI — no dashboard clicking needed after setup)
#
# ONE-TIME SETUP:
#   1. Install Node.js if you don't have it: https://nodejs.org
#   2. Get a Cloudflare API token:
#        dash.cloudflare.com > My Profile > API Tokens > Create Token
#        Use the "Edit Cloudflare Workers" template (it covers Pages too)
#   3. Get your Account ID:
#        dash.cloudflare.com > any domain/overview page, right sidebar > Account ID
#   4. Set both as environment variables (replace with your real values):
#        export CLOUDFLARE_API_TOKEN="your_token_here"
#        export CLOUDFLARE_ACCOUNT_ID="your_account_id_here"
#
# THEN RUN:
#   chmod +x deploy.sh
#   ./deploy.sh
#
# Re-run this same command any time you update the site files — it redeploys automatically.

set -e

PROJECT_NAME="ironclad-home-buyers"
SITE_DIR="$(dirname "$0")"

if [ -z "$CLOUDFLARE_API_TOKEN" ] || [ -z "$CLOUDFLARE_ACCOUNT_ID" ]; then
  echo "Missing CLOUDFLARE_API_TOKEN or CLOUDFLARE_ACCOUNT_ID."
  echo "Set them first — see the setup notes at the top of this script."
  exit 1
fi

echo "Deploying $PROJECT_NAME to Cloudflare Pages..."

# npx pulls Wrangler on the fly — no global install required
npx --yes wrangler pages deploy "$SITE_DIR" \
  --project-name "$PROJECT_NAME" \
  --commit-dirty=true

echo ""
echo "Done. Your site is live at: https://$PROJECT_NAME.pages.dev"
